//------------------------------------------------------------------------------
//             __             __   ___  __
//     | |\ | /  ` |    |  | |  \ |__  /__`
//     | | \| \__, |___ \__/ |__/ |___ .__/
//
//------------------------------------------------------------------------------

#include "adc.h"
#include "sam.h"

//------------------------------------------------------------------------------
//      __   ___  ___         ___  __
//     |  \ |__  |__  | |\ | |__  /__`
//     |__/ |___ |    | | \| |___ .__/
//
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//     ___      __   ___  __   ___  ___  __
//      |  \ / |__) |__  |  \ |__  |__  /__`
//      |   |  |    |___ |__/ |___ |    .__/
//
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//                __          __        ___  __
//     \  /  /\  |__) |  /\  |__) |    |__  /__`
//      \/  /~~\ |  \ | /~~\ |__) |___ |___ .__/
//
//------------------------------------------------------------------------------
//static volatile uint16_t adc_value_x = 0;
//static volatile uint16_t adc_value_y = 0;
static volatile ADC_value adc_value = {0,0};
//------------------------------------------------------------------------------
//      __   __   __  ___  __  ___      __   ___  __
//     |__) |__) /  \  |  /  \  |  \ / |__) |__  /__`
//     |    |  \ \__/  |  \__/  |   |  |    |___ .__/
//
//------------------------------------------------------------------------------

static void sync_register();

static volatile uint8_t toggle = 0;

//------------------------------------------------------------------------------
//      __        __          __
//     |__) |  | |__) |    | /  `
//     |    \__/ |__) |___ | \__,
//
//------------------------------------------------------------------------------

//==============================================================================
void adc_init()
{
  // Setup y axis pins
  PORT->Group[1].PINCFG[PIN_PB08B_ADC_AIN2].bit.INEN = 1;
  PORT->Group[1].DIRCLR.reg = PORT_PB08;
  
  // Setup x axis pins
  PORT->Group[0].PINCFG[PIN_PA02B_ADC_AIN0].bit.INEN = 1;
  PORT->Group[0].DIRCLR.reg = PORT_PA02;

  // GCLK->GENCTRL.reg = GCLK_GENCTRL_GENEN | GCLK_GENCTRL_SRC_XOSC | GCLK_GENCTRL_ID(0);
  GCLK->CLKCTRL.reg = GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_GEN_GCLK0 | GCLK_CLKCTRL_ID_ADC;
  
  // Setup ADC
  ADC->CTRLA.bit.ENABLE = 1;
  sync_register();
  ADC->CTRLB.reg |= ADC_CTRLB_PRESCALER_DIV128 | ADC_CTRLB_RESSEL_12BIT;
  sync_register();
  ADC->REFCTRL.bit.REFSEL = ADC_REFCTRL_REFSEL_INTVCC1;
  sync_register();
  ADC->INPUTCTRL.reg |= ADC_INPUTCTRL_MUXNEG_GND | ADC_INPUTCTRL_MUXPOS_PIN2 | ADC_INPUTCTRL_GAIN_DIV2;
  sync_register();
  ADC->SWTRIG.bit.START = 1;
  sync_register();
  
  // Enable  interrupts
  ADC->INTENSET.bit.RESRDY = 1;
  	NVIC_DisableIRQ(ADC_IRQn);
	NVIC_ClearPendingIRQ(ADC_IRQn);
	NVIC_SetPriority(ADC_IRQn, 0);
	NVIC_EnableIRQ(ADC_IRQn);
} // adc_init

//==============================================================================
ADC_value adc_get()
{
  //sync_register();

  return adc_value;
} // adc_get

/*uint16_t adc_get()
{
	return adc_value_y;
}*/

//------------------------------------------------------------------------------
//      __   __              ___  ___
//     |__) |__) | \  /  /\   |  |__
//     |    |  \ |  \/  /~~\  |  |___
//
//------------------------------------------------------------------------------

//==============================================================================
static void sync_register()
{
  while (ADC->STATUS.bit.SYNCBUSY)
  {
    ; // Wait
  }
}

//------------------------------------------------------------------------------
//      __                  __        __        __
//     /  `  /\  |    |    |__)  /\  /  ` |__/ /__`
//     \__, /~~\ |___ |___ |__) /~~\ \__, |  \ .__/
//
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//        __   __  , __
//     | /__` |__)  /__`   
//     | .__/ |  \  .__/
//
//------------------------------------------------------------------------------
void ADC_Handler(void)
{
	switch(toggle){
		case 0: 
			adc_value.y =  ADC->RESULT.reg;
			//adc_value_y = ADC->RESULT.reg;
			ADC->INPUTCTRL.bit.MUXPOS = ADC_INPUTCTRL_MUXPOS_PIN0;
			
			ADC->SWTRIG.bit.START = 1;
			sync_register(); // NEED THIS???
			toggle = 1;
		break;
		case 1: 
			adc_value.x =  ADC->RESULT.reg;
			//adc_value_x = ADC->RESULT.reg;
			ADC->INPUTCTRL.bit.MUXPOS = ADC_INPUTCTRL_MUXPOS_PIN2;
			ADC->SWTRIG.bit.START = 1;
			sync_register(); // NEED THIS???
			toggle = 0;
		break;
	}
}