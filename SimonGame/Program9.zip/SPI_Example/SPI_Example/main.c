/*****************************************************************
*
* Name : Taylor Dawson
* Program : Program 9
* Class : ENGE 320
* Date : 2017-11-14
* Description : See pdf.
*
* =============================================================
* Program Grading Criteria
* =============================================================
* Pressing S2 selects mode 2: (10) ____
* Mode 2 LED�s fade in correct sequence: (10) ____
* In X direction, led fade follows joystick: (10) ____
* In Y direction, led fade follows joystick: (10) ____
* LED�s flow fluidly with joystick: (10) ____
* Pressing S3 selects mode 3: (10) ____
* Mode 3 LED�s fade in correct sequence: (10) ____
* The Acceleromoter unit is interrupt driven: (10) ____
* In X direction, led fade follows accelerometer: (10) ____
* In Y direction, led fade follows accelerometer: (10) ____
* =============================================================
*
* TOTAL (100)_________
*
* =============================================================
*****************************************************************/
//------------------------------------------------------------------------------
//             __             __   ___  __
//     | |\ | /  ` |    |  | |  \ |__  /__`
//     | | \| \__, |___ \__/ |__/ |___ .__/
//
//------------------------------------------------------------------------------

#include "sam.h"
#include "spi.h"
#include "timer.h"
#include "counter.h"
#include "event.h"
#include "adc.h"
#include <stdio.h>
#include <math.h>
//-----------------------------------------------------------------------------
//      __   ___  ___         ___  __
//     |  \ |__  |__  | |\ | |__  /__`
//     |__/ |___ |    | | \| |___ .__/
//
//-----------------------------------------------------------------------------
#define  MODE_0 (0)
#define  MODE_1 (1)
#define  MODE_2 (2)
#define  MODE_3 (3)
//-----------------------------------------------------------------------------
//     ___      __   ___  __   ___  ___  __
//      |  \ / |__) |__  |  \ |__  |__  /__`
//      |   |  |    |___ |__/ |___ |    .__/
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//                __          __        ___  __
//     \  /  /\  |__) |  /\  |__) |    |__  /__`
//      \/  /~~\ |  \ | /~~\ |__) |___ |___ .__/
//
//-----------------------------------------------------------------------------
static volatile uint64_t millis;
static volatile uint64_t fader;
uint16_t led_values[16];

static uint64_t fade = 0;

//static volatile uint16_t adc_value;

//ADC_value adc_value;
static volatile ADC_value adc_value;

		
static int log_fade[256] = {
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 3, 3, 3, 3, 3, 3, 3,
    3, 4, 4, 4, 4, 4, 4, 5, 5, 5,
    5, 5, 6, 6, 6, 6, 6, 7, 7, 7,
    7, 8, 8, 8, 8, 9, 9, 9, 10, 10,
    10, 10, 11, 11, 11, 12, 12, 12, 13, 13,
    13, 14, 14, 15, 15, 15, 16, 16, 17, 17,
    17, 18, 18, 19, 19, 20, 20, 21, 21, 22,
    22, 23, 23, 24, 24, 25, 25, 26, 26, 27,
    28, 28, 29, 29, 30, 31, 31, 32, 32, 33,
    34, 34, 35, 36, 37, 37, 38, 39, 39, 40,
    41, 42, 43, 43, 44, 45, 46, 47, 47, 48,
    49, 50, 51, 52, 53, 54, 54, 55, 56, 57,
    58, 59, 60, 61, 62, 63, 64, 65, 66, 67,
    68, 70, 71, 72, 73, 74, 75, 76, 77, 79,
    80, 81, 82, 83, 85, 86, 87, 88, 90, 91,
    92, 94, 95, 96, 98, 99, 100, 102, 103, 105,
    106, 108, 109, 110, 112, 113, 115, 116, 118, 120,
    121, 123, 124, 126, 128, 129, 131, 132, 134, 136,
    138, 139, 141, 143, 145, 146, 148, 150, 152, 154,
    155, 157, 159, 161, 163, 165, 167, 169, 171, 173,
    175, 177, 179, 181, 183, 185, 187, 189, 191, 193,
    196, 198, 200, 202, 204, 207, 209, 211, 214, 216,
    218, 220, 223, 225, 228, 230, 232, 235, 237, 240,
    242, 245, 247, 250, 252, 255,
};

typedef struct {
	uint16_t red;
	uint16_t green;
	uint16_t blue;
} Colours;

//-----------------------------------------------------------------------------
//      __   __   __  ___  __  ___      __   ___  __
//     |__) |__) /  \  |  /  \  |  \ / |__) |__  /__`
//     |    |  \ \__/  |  \__/  |   |  |    |___ .__/
//
//-----------------------------------------------------------------------------
void bit_conversion(uint16_t* array, uint8_t* data_array);
int set_led_colour(uint8_t light_select, uint8_t colour, uint8_t fade);
void red_set(uint8_t light_select, uint8_t led_value);
void green_set(uint8_t light_select, uint8_t led_value);
void blue_set(uint8_t light_select, uint8_t led_value);
int mode_1(uint8_t current_colour, uint8_t curr_light, uint8_t fade);
Colours rgb_values(uint16_t value);
static inline clear_led_values();
//-----------------------------------------------------------------------------
//      __        __          __
//     |__) |  | |__) |    | /  `
//     |    \__/ |__) |___ | \__,
//
//-----------------------------------------------------------------------------

int main(void)
{  
 
  /* Initialize the SAM system */
  SystemInit();
  SysTick_Config(48000); //  Configure the SysTick timer for a ms
  
  // Initialize the board
  adc_init();
  timer_init();
  counter_init();
  spi_init();
  event_init();
	
  buttons_init();
  counter_enable();
  timer_enable();
  
  // Initialize the variables
  
  uint64_t current_time = 0;
  uint64_t delay;
  uint64_t previous_time = 0;
  uint8_t data[24];
  int8_t button;
  uint16_t distance;
  int current_light = 1;
  int current_mode = -1;
  int previous_mode = 0;
  uint64_t fader_val = 0;
  
  // set led values to 0
	int colour = set_led_colour(1, 0, 0);
	set_led_colour(2,0,0);
	set_led_colour(3,0,0);
	set_led_colour(4,0,0);
	set_led_colour(5,0,0);
	
	// This turns off all leds
	bit_conversion(led_values, data);
	spi_write(data);

  while (1) 
  {
	  
		current_time = millis;
		adc_value = adc_get();
		
		if (adc_value.y >= 1024)
		{
			delay = (int) 1000*(1 + (1.0 * (1.0 * 5) / (1024)) * (adc_value.y - 1024))/6;
		}
		else
		{
			delay = (int) 1000*((1.0/6) +  (1.0 * (1.0* 1 - (1.0/6)) / (1024)) * (adc_value.y))/6;
		}
	
		bit_conversion(led_values, data);
		spi_write(data);
	
	if((button = buttons_get()) > -1) 
	{
		previous_mode = current_mode;
		current_mode = button;
	}
	
	if (current_time - previous_time >= delay)
	{
		fader = fader > 2047? 0 : fader++;
	}
	
	switch(current_mode)
	{
		case MODE_0:
		
			if (previous_mode != 0) {
				previous_mode = 0;
				clear_led_values();
				colour = set_led_colour(1, 0 , 0);
				bit_conversion(led_values, data);
				spi_write(data);
			}
			
			colour = set_led_colour(1, colour, fade);
			colour = set_led_colour(2, colour, fade);
			colour = set_led_colour(3, colour, fade);
			colour = set_led_colour(4, colour, fade);
			colour = set_led_colour(5, colour, fade);
			
			if (current_time - previous_time >= delay)
			{
				previous_time = current_time;
				if (6 == colour)
				{
					colour = 0;
				}
				colour = set_led_colour(1, colour + 1, 0);
				set_led_colour(2, colour, 0);
				set_led_colour(3, colour, 0);
				set_led_colour(4, colour, 0);
				set_led_colour(5, colour, 0);
			}	
		break;
		
		case MODE_1:
			if (previous_mode != 1)
			{
				previous_mode = 1;
				clear_led_values();
				bit_conversion(led_values, data);
				spi_write(data);
				colour = set_led_colour(1, 0, 0);
				current_light = 1;
			}
			
			colour = mode_1( colour, current_light, fade);
			
			if (current_time - previous_time >= delay)
			{
				previous_time = current_time;
				if (colour == 7)
				{
					colour = 1;
					
					switch(current_light)
					{
						case 2: current_light = 5; break;
						case 5: current_light = 4; break;
						case 4: current_light = 3; break;
						case 3: current_light = 1; break;
						case 1: current_light = 2; break;
					}				
				}
				colour = mode_1( colour + 1, current_light, fade);
			}
		break;
		case MODE_2:
			clear_led_values();
			// Distance from the 'center' of the 'grid'
			distance = sqrt((pow(( abs(adc_value.x - 2048) ), 2))+(pow(( abs(adc_value.y - 2048) ), 2)));
	
			red_set(5, rgb_values(distance).red); green_set(5, rgb_values(distance).green); blue_set(5, rgb_values(distance).blue);

			red_set(4, rgb_values(4096 - adc_value.x).red); green_set(4, rgb_values(4096 - adc_value.x).green); blue_set(4, rgb_values(4096 - adc_value.x).blue);
	
			red_set(2, rgb_values(adc_value.x).red); green_set(2, rgb_values(adc_value.x).green); blue_set(2, rgb_values(adc_value.x).blue);
	
			red_set(1, rgb_values(adc_value.y).red); green_set(1, rgb_values(adc_value.y).green); blue_set(1, rgb_values(adc_value.y).blue);
	
			red_set(3, rgb_values(4096 - adc_value.y).red); green_set(3, rgb_values(4096 - adc_value.y).green); blue_set(3, rgb_values(4096 - adc_value.y).blue);
		break;
		case MODE_3:
			clear_led_values();
			red_set(5, rgb_values(fader).red); green_set(5, rgb_values(fader).green); blue_set(5, rgb_values(fader).blue);

			red_set(4, rgb_values(fader).red); green_set(4, rgb_values(fader).green); blue_set(4, rgb_values(fader).blue);
	
			red_set(2, rgb_values(fader).red); green_set(2, rgb_values(fader).green); blue_set(2, rgb_values(fader).blue);
	
			red_set(1, rgb_values(fader).red); green_set(1, rgb_values(fader).green); blue_set(1, rgb_values(fader).blue);
	
			red_set(3, rgb_values(fader).red); green_set(3, rgb_values(fader).green); blue_set(3, rgb_values(fader).blue);
		
		break;
	}
	
	
	
  }
}
//==============================================================================

Colours rgb_values(uint16_t value)
{
	
	uint16_t adc_val = value % 256;
	uint8_t adc_state = value / 256;
	
	Colours colours = {0,0,0};
		
	switch(adc_state){
		case 0: // WHITE
			colours.red   = log_fade[255 - adc_val]; //red_set(5, log_fade[255 - adc_val]); 
			colours.green = 255;				//green_set(5, 255);			 
			colours.blue  = 255;				// blue_set(5, 255);
		break;
		case 1: // CYAN
			colours.red   = 0;					//blue_set(5, log_fade[255 - adc_val]);
			colours.green = 255;				//green_set(5, 255);
			colours.blue  = log_fade[255 - adc_val]; //red_set(5, 0);
		break;
		case 2: // GREEN
			colours.red   = log_fade[adc_val];		//red_set(5, log_fade[adc_val]);
			colours.green = 255;				//green_set(5, 255);
			colours.blue  = 0;					//blue_set(5, 0);
		break;
		case 3: // YELLOW
			colours.red   = 255;				
			colours.green = log_fade[255 - adc_val];	
			colours.blue  = 0;				
		break;
		case 4: // RED
			colours.red   = 255;				//red_set(5, log_fade[255 - adc_val]);
			colours.green = 0;					//blue_set(5, 0);
			colours.blue  = log_fade[adc_val];		//green_set(5, 0);
		break;
		case 5: // BLUE (MAGENTA)
			colours.red   = log_fade[255 - adc_val];	//blue_set(5, log_fade[adc_val]);
			colours.green = 0;					//red_set(5, log_fade[255 - adc_val]);
			colours.blue  = 255;				//green_set(5, 0);
		break;
		case 6: // OFF (BLUE)
			colours.red   =	0;					// blue_set(5, log_fade[255 - adc_val]);
			colours.green =	0;					// red_set(5, 0);
			colours.blue  = log_fade[255 - adc_val]; // green_set(5, 0);
		break;
		case 7:
			colours.red   =	0;					//blue_set(5, 0);
			colours.green =	0;					//red_set(5, 0);
			colours.blue  = 0;					//green_set(5, 0);
		break;
		default:
		break;
	}
	
	return colours;
}

//==============================================================================
void bit_conversion(uint16_t* array, uint8_t* data_array)
{
	uint8_t ind = 0;
	
	for (int i = 8; i > 0; i--)
	{
		data_array[ind++] = (array[i * 2 - 1] & 0x0FF0) >> 4;
		data_array[ind++] = ((array[i * 2 - 1] & 0x000F) << 4) | ((array[i * 2 - 2] & 0x0F00) >> 8);
		data_array[ind++] = array[i * 2 - 2] & 0x00FF;
	}
}

//==============================================================================
int set_led_colour(uint8_t light_select, uint8_t colour, uint8_t fade)
{
	switch(colour)
	{
		case 0:red_set(light_select, log_fade[fade]); return colour;
		case 1:green_set(light_select, log_fade[fade]); return colour;
		case 2:red_set(light_select, log_fade[255 - fade]); return colour;
		case 3:blue_set(light_select, log_fade[fade]); return colour;
		case 4:green_set(light_select, log_fade[255 - fade]); return colour;
		case 5:red_set(light_select, log_fade[fade]); return colour;
		case 6:blue_set(light_select, log_fade[255 - fade]); return colour;
	}
}

//==============================================================================
int mode_1(uint8_t current_colour, uint8_t curr_light, uint8_t fade)
{
	// Simple light state machine
	
	int next_light = curr_light + 1;
	int prev_light = curr_light - 1;
	
	switch(curr_light)
	{
		case 2: next_light = 5; break;
		case 5: next_light = 4; break;
		case 4: next_light = 3; break;
		case 3: next_light = 1; break;
		case 1: next_light = 2; break;
	}
	
	switch(curr_light)
	{
		case 5: prev_light = 2; break;
		case 2: prev_light = 1; break;
		case 1: prev_light = 3; break;
		case 3: prev_light = 4; break;
		case 4: prev_light = 5; break;
	}
	
	if (0 == current_colour)
	{
		blue_set(curr_light, log_fade[fade]);
	}
	if (1 == current_colour)
	{
		red_set(curr_light , log_fade[fade]);
	}
	if (2 == current_colour)
	{
		blue_set (prev_light, 0);
		red_set  (prev_light, 0);
		green_set(prev_light, 0);
		
		blue_set(curr_light,log_fade[255 - fade]);
	}
	if (3 == current_colour)
	{
		green_set(curr_light, log_fade[fade]);
	}
	if (4 == current_colour)
	{
		red_set(curr_light, log_fade[255- fade]);
	}
	if (5 == current_colour)
	{
		blue_set(curr_light,log_fade[fade]);
	}
	if (6 == current_colour)
	{	
		green_set(curr_light, log_fade[255 - fade]);
		blue_set (next_light, log_fade[fade]);
		
	}
	if (7 == current_colour)
	{	
		blue_set(curr_light, log_fade[255-fade]);
		red_set (next_light, log_fade[fade]);
	}
	
	return current_colour;
}

//==============================================================================
void red_set(uint8_t light_select, uint8_t led_value)
{
	led_values[light_select*3-3] = led_value * 16;
}

//==============================================================================
void green_set(uint8_t light_select, uint8_t led_value)
{
	led_values[light_select*3-2] = led_value * 16;
}

//==============================================================================
void blue_set(uint8_t light_select, uint8_t led_value)
{
	led_values[light_select*3-1] = led_value * 16;
}

//==============================================================================
static inline clear_led_values()
{
	for( int i = 0; i < 16; i++)
	{
		led_values[i] = 0;
	}
}

//-----------------------------------------------------------------------------
//        __   __   __
//     | /__` |__) /__`
//     | .__/ |  \ .__/
//
//-----------------------------------------------------------------------------
void SysTick_Handler()
{
	millis++;
}
