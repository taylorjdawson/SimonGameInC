/*****************************************************************
*
* Name : Taylor Dawson
* Program : Program 8
* Class : ENGE 320
* Date : 2017-11-7
* Description : See pdf.
*
* =============================================================
* Program Grading Criteria
* =============================================================
* Pressing S0 selects mode 0: (10) ____
* Mode 0 LED�s fade in correct sequence: (10) ____
* Without joystick, Mode 0 LED�s fade a full cycle in 1 second: (10) ____
* When joystick up, Mode 0 LED�s fade a full cycle in 1/6 of a second: (10) ____
* When joystick down, Mode 0 LED�s fade a full cycle in 6 seconds: (10) ____
* Mode 0 Joystick up/down varies timing linearly: (10) ____
* Pressing S1 selects mode 1: (10) ____
* Mode 1 LED�s fade in correct sequence: (10) ____
* Without joystick, Mode 1 LED�s fade a full cycle in 1 second: (10) ____
* When joystick up, Mode 1 LED�s fade a full cycle in 1/6 of a second: (10) ____
* When joystick down, Mode 1 LED�s fade a full cycle in 6 seconds: (10) ____
* Mode 1 joystick up/down varies timing linearly: (10) ____
* =============================================================
*
* TOTAL (100)_________
*
* =============================================================
*****************************************************************/
//------------------------------------------------------------------------------
//             __             __   ___  __
//     | |\ | /  ` |    |  | |  \ |__  /__`
//     | | \| \__, |___ \__/ |__/ |___ .__/
//
//------------------------------------------------------------------------------

#include "sam.h"
#include "spi.h"
#include "timer.h"
#include "counter.h"
#include "event.h"

//-----------------------------------------------------------------------------
//      __   ___  ___         ___  __
//     |  \ |__  |__  | |\ | |__  /__`
//     |__/ |___ |    | | \| |___ .__/
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//     ___      __   ___  __   ___  ___  __
//      |  \ / |__) |__  |  \ |__  |__  /__`
//      |   |  |    |___ |__/ |___ |    .__/
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//                __          __        ___  __
//     \  /  /\  |__) |  /\  |__) |    |__  /__`
//      \/  /~~\ |  \ | /~~\ |__) |___ |___ .__/
//
//-----------------------------------------------------------------------------
static volatile uint64_t millis;
uint16_t led_values[16];
	
static int LINEAR_FADE_IN[] = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 3,
	3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 9,
	9, 9, 10, 10, 10, 11, 11, 12, 12, 12, 13, 13, 14, 14, 15, 15, 15, 16, 16,
	17, 17, 18, 18, 19, 19, 20, 20, 21, 22, 22, 23, 23, 24, 25, 25, 26, 26,
	27, 28, 28, 29, 30, 30, 31, 32, 33, 33, 34, 35, 36, 36, 37, 38, 39, 40,
	40, 41, 42, 43, 44, 45, 46, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56,
	57, 58, 59, 60, 61, 62, 63, 64, 65, 67, 68, 69, 70, 71, 72, 73, 75, 76,
	77, 78, 80, 81, 82, 83, 85, 86, 87, 89, 90, 91, 93, 94, 95, 97, 98, 99,
	101, 102, 104, 105, 107, 108, 110, 111, 113, 114, 116, 117, 119, 121, 122,
	124, 125, 127, 129, 130, 132, 134, 135, 137, 139, 141, 142, 144, 146, 148,
	150, 151, 153, 155, 157, 159, 161, 163, 165, 166, 168, 170, 172, 174, 176,
	178, 180, 182, 184, 186, 189, 191, 193, 195, 197, 199, 201, 204, 206, 208,
	210, 212, 215, 217, 219, 221, 224, 226, 228, 231, 233, 235, 238, 240, 243,
	245, 248, 250, 253, 255};
	
static int LINEAR_FADE_OUT[] = {255, 253, 250, 248, 245, 243, 240, 238, 235,
		233, 231, 228, 226, 224, 221, 219, 217, 215, 212, 210, 208, 206, 204, 201,
		199, 197, 195, 193, 191, 189, 186, 184, 182, 180, 178, 176, 174, 172, 170,
		168, 166, 165, 163, 161, 159, 157, 155, 153, 151, 150, 148, 146, 144, 142,
		141, 139, 137, 135, 134, 132, 130, 129, 127, 125, 124, 122, 121, 119, 117,
		116, 114, 113, 111, 110, 108, 107, 105, 104, 102, 101, 99, 98, 97, 95, 94,
		93, 91, 90, 89, 87, 86, 85, 83, 82, 81, 80, 78, 77, 76, 75, 73, 72, 71,
		70, 69, 68, 67, 65, 64, 63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52,
		51, 50, 49, 48, 47, 46, 46, 45, 44, 43, 42, 41, 40, 40, 39, 38, 37, 36,
		36, 35, 34, 33, 33, 32, 31, 30, 30, 29, 28, 28, 27, 26, 26, 25, 25, 24,
		23, 23, 22, 22, 21, 20, 20, 19, 19, 18, 18, 17, 17, 16, 16, 15, 15, 15,
		14, 14, 13, 13, 12, 12, 12, 11, 11, 10, 10, 10, 9, 9, 9, 8, 8, 8, 7, 7,
		7, 7, 6, 6, 6, 6, 5, 5, 5, 5, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 2, 2, 2, 2,
		2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0};

//-----------------------------------------------------------------------------
//      __   __   __  ___  __  ___      __   ___  __
//     |__) |__) /  \  |  /  \  |  \ / |__) |__  /__`
//     |    |  \ \__/  |  \__/  |   |  |    |___ .__/
//
//-----------------------------------------------------------------------------
void bit_conversion(uint16_t* array, uint8_t* data_array);
int set_led_colour(uint8_t light_select, uint8_t colour, uint8_t fade);
void red_set(uint8_t light_select, uint8_t led_value);
void green_set(uint8_t light_select, uint8_t led_value);
void blue_set(uint8_t light_select, uint8_t led_value);
int mode_1(uint8_t current_colour, uint8_t curr_light, uint8_t fade);

//-----------------------------------------------------------------------------
//      __        __          __
//     |__) |  | |__) |    | /  `
//     |    \__/ |__) |___ | \__,
//
//-----------------------------------------------------------------------------

int main(void)
{  
 
  /* Initialize the SAM system */
  SystemInit();
  SysTick_Config(48000); //  Configure the SysTick timer for a ms
  
  // Initialize the board
  adc_init();
  timer_init();
  counter_init();
  spi_init();
  event_init();
	
	buttons_init();
  counter_enable();
  timer_enable();
  
  // Initialize the variables
  uint64_t fade = 0;
  uint64_t current_time = 0;
  uint64_t delay;
  uint64_t previous_time = 0;
  uint8_t data[24];
  int8_t button;
  	
  int current_light = 1;
  int current_mode = -1;
  int previous_mode = 0;
  
  // set led values to 0
	int colour = set_led_colour(1, 0, 0);
	set_led_colour(2,0,0);
	set_led_colour(3,0,0);
	set_led_colour(4,0,0);
	set_led_colour(5,0,0);
	
  while (1) 
  {
	current_time = millis;
	
	if (adc_get() >= 128)
	{
		delay = (int) 1000*(1 + (1.0 * (1.0 * 5) / (127)) * (adc_get() - 128))/6;
	}
	else
	{
		delay = (int) 1000*((1.0/6) +  (1.0 * (1.0* 1 - (1.0/6)) / (128)) * (adc_get()))/6;
	}
	
	bit_conversion(led_values, data);
	spi_write(data);
	fade = ( (current_time - previous_time) * 255 / delay);
	
	if((button = buttons_get()) > -1)
	{
		if (buttons_get() == 1 || buttons_get() == 2)
		{
			previous_mode = current_mode;
			current_mode = buttons_get() - 1;
		}
	}
	if (current_mode == 1)
	{
		if (previous_mode == 0)
		{
			previous_mode = 1;
			for (int i = 0; i < 16; i++)
			{
				led_values[i] = 0;
			}
			bit_conversion(led_values, data);
			spi_write(data);
			colour = set_led_colour(1, 0, 0);
			current_light = 1;
		}
		colour = mode_1( colour, current_light, fade);
		if (current_time - previous_time >= delay)
		{
			previous_time = current_time;
			if (colour == 7)
			{
				colour = 1;
					
				switch(current_light)
				{
					case 2: current_light = 5; break;
					case 5: current_light = 4; break;
					case 4: current_light = 3; break;
					case 3: current_light = 1; break;
					case 1: current_light = 2; break;
				}				
			}
			colour = mode_1( colour + 1, current_light, fade);
		}
	}
	if(current_mode == 0) 
	{
		if(previous_mode)
		{
			previous_mode = 0;
			
			// Set them back to 0
			for( int i = 0; i < 16; i++)
			{
				led_values[i] = 0;
			}
			colour = set_led_colour(1, 0 , 0);
			bit_conversion(led_values, data);
			spi_write(data);
		}
			
		colour = set_led_colour(1, colour, fade);
		colour = set_led_colour(2, colour, fade);
		colour = set_led_colour(3, colour, fade);
		colour = set_led_colour(4, colour, fade);
		colour = set_led_colour(5, colour, fade);
					
		if (current_time - previous_time >= delay)
		{
			previous_time = current_time;
			if (6 == colour)
			{
				colour = 0;
			}

			colour = set_led_colour(1, colour + 1, 0);
			set_led_colour(2, colour, 0);
			set_led_colour(3, colour, 0);
			set_led_colour(4, colour, 0);
			set_led_colour(5, colour, 0);
		}	
	}
	
  }
}

//==============================================================================
void bit_conversion(uint16_t* array, uint8_t* data_array)
{
	uint8_t ind = 0;
	
	for (int i = 8; i > 0; i--)
	{
		data_array[ind++] = (array[i * 2 - 1] & 0x0FF0) >> 4;
		data_array[ind++] = ((array[i * 2 - 1] & 0x000F) << 4) | ((array[i * 2 - 2] & 0x0F00) >> 8);
		data_array[ind++] = array[i * 2 - 2] & 0x00FF;
	}
}

//==============================================================================
int set_led_colour(uint8_t light_select, uint8_t colour, uint8_t fade)
{
	switch(colour)
	{
		case 0:red_set(light_select, LINEAR_FADE_IN[fade]); return colour;
		case 1:green_set(light_select, LINEAR_FADE_IN[fade]); return colour;
		case 2:red_set(light_select, LINEAR_FADE_OUT[fade]); return colour;
		case 3:blue_set(light_select, LINEAR_FADE_IN[fade]); return colour;
		case 4:green_set(light_select, LINEAR_FADE_OUT[fade]); return colour;
		case 5:red_set(light_select, LINEAR_FADE_IN[fade]); return colour;
		case 6:blue_set(light_select, LINEAR_FADE_OUT[fade]); return colour;
	}
}

//==============================================================================
int mode_1(uint8_t current_colour, uint8_t curr_light, uint8_t fade)
{
	// Simple light state machine
	
	int next_light = curr_light + 1;
	int prev_light = curr_light - 1;
	
	switch(curr_light)
	{
		case 2: next_light = 5; break;
		case 5: next_light = 4; break;
		case 4: next_light = 3; break;
		case 3: next_light = 1; break;
		case 1: next_light = 2; break;
	}
	
	switch(curr_light)
	{
		case 5: prev_light = 2; break;
		case 2: prev_light = 1; break;
		case 1: prev_light = 3; break;
		case 3: prev_light = 4; break;
		case 4: prev_light = 5; break;
	}
	
	if (0 == current_colour)
	{
		blue_set(curr_light, LINEAR_FADE_IN[fade]);
	}
	if (1 == current_colour)
	{
		red_set(curr_light , LINEAR_FADE_IN[fade]);
	}
	if (2 == current_colour)
	{
		blue_set (prev_light, 0);
		red_set  (prev_light, 0);
		green_set(prev_light, 0);
		
		blue_set(curr_light,LINEAR_FADE_OUT[fade]);
	}
	if (3 == current_colour)
	{
		green_set(curr_light, LINEAR_FADE_IN[fade]);
	}
	if (4 == current_colour)
	{
		red_set(curr_light, LINEAR_FADE_OUT[fade]);
	}
	if (5 == current_colour)
	{
		blue_set(curr_light,LINEAR_FADE_IN[fade]);
	}
	if (6 == current_colour)
	{	
		green_set(curr_light, LINEAR_FADE_OUT[fade]);
		blue_set (next_light, LINEAR_FADE_IN[fade]);
		
	}
	if (7 == current_colour)
	{	
		blue_set(curr_light, LINEAR_FADE_OUT[fade]);
		red_set (next_light, LINEAR_FADE_IN[fade]);
	}
	
	return current_colour;
}

//==============================================================================
void red_set(uint8_t light_select, uint8_t led_value)
{
	led_values[light_select*3-3] = led_value * 16;
}

//==============================================================================
void green_set(uint8_t light_select, uint8_t led_value)
{
	led_values[light_select*3-2] = led_value * 16;
}

//==============================================================================
void blue_set(uint8_t light_select, uint8_t led_value)
{
	led_values[light_select*3-1] = led_value * 16;
}
//-----------------------------------------------------------------------------
//        __   __   __
//     | /__` |__) /__`
//     | .__/ |  \ .__/
//
//-----------------------------------------------------------------------------
void SysTick_Handler()
{
	millis++;
}
